#import the required libraries
library(DataExplorer)
library(corrplot)
library(caTools)
library(caret)
library(ROCR)

#Check for the missing values
anyNA(CancerData)
str(CancerData)
#Here column x33 contains missing values.
CancerData$X33<-NULL

#plot structure of cancer data

plot_str(CancerData)

#find out the total number of diagnosis for better understanding!


text(barplot(table(CancerData$diagnosis),col=c('green','red'),main='Bar plot of Diagnosis')
     ,0,table(CancerData$diagnosis),cex=2,pos=3)


# Check for Correlated variables.
#if the corelated variables are red then it is highly corelated and is considered as insignificant variables.
#if the corelated variables are blue then it is normal
corrplot(cor(CancerData[sapply(CancerData, is.numeric)]))

# Keep the highly correlated variables. i.e all the variables with blue dots.
# Remove the non corelated variables.
# then remvove the unnecessary variables.

CancerData$id<-NULL
CancerData$smoothness_se<-NULL
CancerData$compactness_se<-NULL
CancerData$concavity_se<-NULL
CancerData$`concave points_se`<-NULL
CancerData$symmetry_se <-NULL
CancerData$radius_se<-NULL
CancerData$texture_se<-NULL
CancerData$perimeter_se<-NULL
CancerData$area_se<-NULL
CancerData$fractal_dimension_se<-NULL
CancerData$symmetry_mean<-NULL
CancerData$fractal_dimension_mean<-NULL
CancerData$symmetry_worst<-NULL
CancerData$fractal_dimension_worst<-NULL
CancerData$smoothness_worst<-NULL
CancerData$smoothness_mean<-NULL
CancerData$texture_worst<-NULL
CancerData$compactness_mean<-NULL
CancerData$concavity_mean<-NULL
CancerData$`concave points_mean`<-NULL
CancerData$texture_mean<-NULL
CancerData$compactness_worst<-NULL
CancerData$concavity_worst<-NULL
CancerData$`concave points_worst`<-NULL

# Convert Malignant(M) in diagnosis column to 1 and Benign(B) in diagnosis column to 0.
# Malignant means the type of cancer which spreads throughout the body.
# Benign means the type of cancer which does not spread throughout the body.

CancerData$diagnosis[CancerData$diagnosis=="M"]<-'1'
CancerData$diagnosis[CancerData$diagnosis=="B"]<-'0'

View(CancerData)
CancerData$diagnosis<-as.numeric(CancerData$diagnosis)
# Now perform logistic regression

set.seed(101)
split<-sample.split(CancerData,SplitRatio = 0.75)
split
training<-subset(CancerData,split=="TRUE")
testing<-subset(CancerData,split=="FALSE")
model<-glm(diagnosis~.,training,family ="binomial")
summary(model)

#optimize the model by removing independent variables.
# after removing the independent variables from the model make sure the residual deviance should not increase
# and AIC value should decrease.
model<-glm(diagnosis~.-radius_worst,training,family ="binomial")
summary(model)

# Now predict the values for testing dataset and predict the accuracy of the model type=reponse means
# we want the probability of the testing dataset.

res<-predict(model,testing,type = "response")
res
testing

# Now find the threshold using ROC curve
res<-predict(model,training,type = "response")
ROCRpred=prediction(res,training$diagnosis)
ROCRperf<-performance(ROCRpred,"tpr","fpr")
plot(ROCRperf,colorize=TRUE,print.cutoffs.at=seq(0.1,by=0.1))

#now the graph says threshold value is 0.2 

# Now create the confusion matrix
res<-predict(model,testing,type = "response")
table(Actualvalue=testing$diagnosis,Predictedvalue=res>0.2)

#this model is 92.59 % accurate.

# Now calculate odds ratio
exp(confint(model))
#the odds ratio says that with the increase in 1 unit of perimeter_mean the probability of increasing the cancer to be malignant is 56.46%.



